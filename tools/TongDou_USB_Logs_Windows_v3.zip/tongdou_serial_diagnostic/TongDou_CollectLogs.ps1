﻿#requires -Version 5.1
$ErrorActionPreference='Stop'
$baud=115200
function Ports {
  $dev=@(Get-CimInstance Win32_PnPEntity -ErrorAction SilentlyContinue | Where-Object {$_.Name -match '\(COM\d+\)'})
  foreach($n in [IO.Ports.SerialPort]::GetPortNames()){
    $p=$dev|Where-Object{$_.Name -match ('\('+[regex]::Escape($n)+'\)')}|Select-Object -First 1
    [pscustomobject]@{Name=$n;Label=$(if($p){$p.Name}else{$n});Id=$(if($p){$p.PNPDeviceID}else{''})}
  }
}
function OpenPort($n) {
  $p=[IO.Ports.SerialPort]::new($n,$baud,[IO.Ports.Parity]::None,8,[IO.Ports.StopBits]::One)
  $p.ReadTimeout=100;$p.Encoding=[Text.Encoding]::UTF8;$p.DtrEnable=$false;$p.RtsEnable=$false;$p.Open();return $p
}
function Mark($s){'[ {0} ] {1}' -f (Get-Date).ToString('yyyy-MM-ddTHH:mm:ss.fffK'),$s}
$port=$null;$out=$null;$file=$null;$count=0
try{
  Write-Host 'TongDou USB — запись журнала' -ForegroundColor Cyan
  Write-Host 'Подключите USB-кабель с передачей данных. Закройте другие COM-мониторы.'
  $all=@()
  for($i=0;$i -lt 45;$i++){$all=@(Ports);if($all.Count){break};Start-Sleep 2}
  if(!$all.Count){throw 'COM-порт не обнаружен: проверьте кабель, питание и драйвер.'}
  $likely=@($all|Where-Object{$_.Id -match 'VID_(303A|10C4|1A86|0403)' -or $_.Label -match 'USB|CP210|CH340|Espressif|FTDI'})
  if($all.Count -eq 1){$dev=$all[0]}
  elseif($likely.Count -eq 1){$dev=$likely[0]}
  else{
    for($i=0;$i -lt $all.Count;$i++){Write-Host ('{0}: {1}' -f ($i+1),$all[$i].Label)}
    do{$x=Read-Host 'Введите номер COM-порта';$n=0;$ok=[int]::TryParse($x,[ref]$n) -and $n -gt 0 -and $n -le $all.Count}until($ok)
    $dev=$all[$n-1]
  }
  $dir=Join-Path $PSScriptRoot 'logs';[void][IO.Directory]::CreateDirectory($dir)
  $file=Join-Path $dir ('TongDou_{0}_{1}.txt' -f (Get-Date -Format 'yyyyMMdd_HHmmss'),$dev.Name)
  $out=[IO.StreamWriter]::new($file,$false,[Text.UTF8Encoding]::new($true));$out.AutoFlush=$true
  $out.WriteLine((Mark ('CAPTURE_STARTED COM='+$dev.Name+' BAUD='+$baud)))
  $port=OpenPort $dev.Name
  Write-Host ('Журнал: '+$file) -ForegroundColor Green
  Write-Host 'Начните снимать ТОЛЬКО робота на телефон, со звуком. Монитор компьютера не нужен.' -ForegroundColor Green
  [void](Read-Host 'Когда видео записывается, нажмите ENTER')
  $out.WriteLine((Mark 'VIDEO_STARTED_BY_USER'))
  if($dev.Id -match 'VID_(10C4|1A86|0403)' -or $dev.Label -match 'CP210|CH340|FTDI'){
    Write-Host 'Попытка перезапуска через RTS...'
    try{$port.RtsEnable=$true;Start-Sleep -Milliseconds 160;$port.RtsEnable=$false;$out.WriteLine((Mark 'RTS_RESET_ATTEMPT'))}catch{}
  }
  Write-Host 'Если робот не перезапустился, выключите его тумблером на 5 секунд и включите.' -ForegroundColor Yellow
  Write-Host 'Дождитесь звукового сигнала; ОДИН РАЗ коснитесь золотистого логотипа (это пробуждение).' -ForegroundColor Green
  Write-Host 'Сразу скажите: «Привет, Тунду! Как дела?» Подождите 10 секунд.' -ForegroundColor Green
  Write-Host 'Если ответа нет, повторите одно касание и фразу ещё раз.' -ForegroundColor Green
  Write-Host 'После теста нажмите ENTER, остановите видео. Максимум 3 минуты.' -ForegroundColor Cyan
  $out.WriteLine((Mark 'TEST_BEGIN'));$started=Get-Date
  while(((Get-Date)-$started).TotalSeconds -lt 180){
    try{
      if(!$port.IsOpen){throw 'Port closed'}
      $s=$port.ReadExisting()
      if($s.Length){[Console]::Write($s);$out.Write($s);$count+=$s.Length}
    }catch{
      $out.WriteLine((Mark ('SERIAL_DISCONNECTED '+$_.Exception.Message)))
      try{$port.Dispose()}catch{};$port=$null;$back=$false
      Write-Host 'COM-порт пропал. Ожидание до 45 секунд...' -ForegroundColor Yellow
      for($j=0;$j -lt 45;$j++){
        Start-Sleep 1;$avail=@(Ports)
        $match=@($avail|Where-Object{($_.Id -and $_.Id -eq $dev.Id) -or $_.Name -eq $dev.Name})
        if(!$match.Count){$match=@($avail|Where-Object{$_.Id -match 'VID_(303A|10C4|1A86|0403)'});if($match.Count -ne 1){continue}}
        try{$port=OpenPort $match[0].Name;$dev=$match[0];$out.WriteLine((Mark ('SERIAL_RECONNECTED '+$dev.Name)));$back=$true;break}catch{}
      }
      if(!$back){$out.WriteLine((Mark 'RECONNECT_TIMEOUT'));break}
    }
    try{if([Console]::KeyAvailable){if([Console]::ReadKey($true).Key -eq [ConsoleKey]::Enter){$out.WriteLine((Mark 'USER_FINISHED'));break}}}catch{}
    Start-Sleep -Milliseconds 100
  }
  $out.WriteLine((Mark ('CAPTURE_FINISHED CHARS='+$count)))
}catch{Write-Host ('ОШИБКА: '+$_.Exception.Message) -ForegroundColor Red;if($out){$out.WriteLine((Mark ('ERROR '+$_.Exception.Message)))}}
finally{if($port){try{$port.Close();$port.Dispose()}catch{}};if($out){$out.Flush();$out.Close();$out.Dispose()}}
if($file -and [IO.File]::Exists($file)){
  Write-Host ('Сохранено: '+$file) -ForegroundColor Green
  Write-Host 'Проверьте файл на пароли Wi-Fi и секретные ключи. Отправьте TXT + видео одним письмом.' -ForegroundColor Yellow
  try{Start-Process notepad.exe -ArgumentList @('"' + $file + '"')}catch{}
}
